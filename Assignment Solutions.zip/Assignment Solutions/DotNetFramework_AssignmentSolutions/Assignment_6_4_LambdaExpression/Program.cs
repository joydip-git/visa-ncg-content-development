﻿using System;

namespace Assignment_6_4_LambdaExpression
{
    //delegate int AddTwoNumbers(int x, int y);
    //delegate int AddTwoNumbers<in T1, in T2>(T1 x, T2 y);
    delegate TResult AddTwoNumbers<in T1, in T2, out TResult>(T1 x, T2 y);
    class Program
    {
        static void Main()
        {
            //anonymous method and delegate  (non-generic)
            //AddTwoNumbers addTwoNumbers = delegate (int x, int y)
            //{
            //    return (x + y);
            //};

            //anonymous method represented by Lambda Expression
            //AddTwoNumbers addTwoNumbers = (x, y) => (x + y);

            //the same Lambda Expression but now with generic delegate (only arguments are generic NOT the return type)
            //AddTwoNumbers<int, int> addTwoNumbers = (x, y) => (x + y);

            //the same Lambda Expression but now with generic delegate where return type is also generic
            AddTwoNumbers<int, int, int> addTwoNumbers = (x, y) => (x + y);

            int result = addTwoNumbers(12, 13);
            Console.WriteLine(result);

            //the same can be achieved by the built-in delegate Func<>
            Func<int, int, int> addNumbers = (x, y) => (x + y);
            int funcResult = addNumbers(12, 13);
            Console.WriteLine(funcResult);
        }
    }
}
