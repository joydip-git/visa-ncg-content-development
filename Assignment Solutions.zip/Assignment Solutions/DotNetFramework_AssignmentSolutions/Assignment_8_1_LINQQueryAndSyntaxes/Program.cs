﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8_1_LINQQueryAndSyntaxes
{
    class Program
    {
        static void GroupWordsWithSameFirstLetter()
        {
            string[] words = { "Animal", "Grapes", "Pearl", "Grain", "Apple", "Pineapple" };
            var query = from word in words
                        orderby word[0]
                        group word by word[0];

            foreach (var wordGroup in query)
            {
                StringBuilder builder = new StringBuilder($"Words that starts with letter {wordGroup.Key}: ");
                foreach (var word in wordGroup)
                {
                    builder.Append(word);
                    builder.Append(" ");
                }
                Console.WriteLine(builder.ToString());
            }
        }
        static void SortDigits()
        {
            string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var query = from d in digits
                        orderby d.Length, d[0]
                        select d;
            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }
        static void CreateSequence()
        {
            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 1, 3, 5, 7, 8 };

            var query = from a in numbersA.Union(numbersB)
                        select a;


            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

        }
        static void SequenecOfStrings()
        {
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            string[] strings = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var query = from n in numbers
                        select strings[n];
            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }
        static void Main()
        {
            GroupWordsWithSameFirstLetter();
            SortDigits();
            CreateSequence();
            SequenecOfStrings();
        }
    }
}
