﻿using System;

namespace Assignment_6_1_StringOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            StringOperationCls stringOperation = new StringOperationCls();
            StringOp stringOp = new StringOp(stringOperation.CharacterReplace);
            stringOp += stringOperation.CharaterRemove;
            stringOp += stringOperation.ReverseString;

            Console.WriteLine("enter a sentence: ");
            string sentence = Console.ReadLine();
            stringOp(ref sentence);
        }
    }
}
