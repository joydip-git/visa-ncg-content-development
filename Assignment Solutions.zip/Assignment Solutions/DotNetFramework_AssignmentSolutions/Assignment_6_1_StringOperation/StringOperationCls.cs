﻿namespace Assignment_6_1_StringOperation
{
    delegate void StringOp(ref string input);
    public class StringOperationCls
    {
        public void CharacterReplace(ref string inputString)
        {
            string output = null;
            foreach (char ch in inputString)
            {
                if (ch != ' ')
                {
                    output += ch;
                }
                else
                {
                    output += '_';
                }
            }
            inputString = output;
            System.Console.WriteLine(inputString);
        }
        public void CharaterRemove(ref string inputString)
        {
            string output = null;
            foreach (char ch in inputString)
            {
                if (ch != '_')
                {
                    output += ch;
                }
            }
            inputString = output;
            System.Console.WriteLine(inputString);
        }
        public void ReverseString(ref string inputString)
        {
            string output = null;
            for (int i = inputString.Length - 1; i > 0; i--)
            {
                output += inputString[i];
            }
            inputString = output;
            System.Console.WriteLine(inputString);
        }
    }
}
