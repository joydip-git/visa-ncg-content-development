﻿using System;
using System.IO;
using System.Text;

namespace Assignment_3_2_Banking_Application.Utility
{
    public static class Logger
    {
        static string filePath = @"..\..\log.txt";
        public static void Log(bool transactionStatus, DateTime transactionTime, Exception ex = null)
        {
            if (File.Exists(filePath))
            {
                StreamWriter writer = null;
                using (writer = new StreamWriter(filePath, true))
                {
                    StringBuilder builder = new StringBuilder();
                    builder.AppendLine($"Time: {transactionTime.ToString()}");
                    builder.AppendLine($"Status: {transactionStatus}");
                    if (ex != null)
                    {
                        builder.AppendLine($"Error: {ex.Message}");
                    }
                    writer.WriteLine(builder.ToString());
                }
            }
        }
    }
}
