﻿using Assignment_3_2_Banking_Application.CustomExceptions;
using Assignment_3_2_Banking_Application.Utility;
using System;

namespace Assignment_3_2_Banking_Application.Entities
{
    public static class BankService
    {
        //initial set up
        private static Account[] accounts = new Account[5];

        public static bool CreateAccount(string name, double initialBalance, int accountNumber)
        {
            try
            {
                if (name == null || name == string.Empty)
                {
                    throw new AccountCreationException("name must be supplied");
                }
                if (initialBalance < 500)
                {
                    throw new AccountCreationException("initial balance must be equal to or more than 500");
                }
                if (AccountExists(accountNumber))
                {
                    throw new AccountCreationException("account number already exists...");
                }

                return SaveAccount(new Account(accountNumber, name, initialBalance));
            }
            catch (AccountCreationException ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw ex;
            }
            catch (Exception ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw ex;
            }
        }

        public static bool TransferFund(int debitAccNo, int creditAccNo, double amount)
        {
            Account debitAccount = GetAccountDetails(debitAccNo);
            Account creditAccount = GetAccountDetails(creditAccNo);
            try
            {
                if (debitAccount == null)
                    throw new AccountTransactionException("incorrect debit acount nnumber");

                if (creditAccount == null)
                    throw new AccountTransactionException("incorrect credit acount nnumber");


                bool debitStatus = debitAccount.Withdraw(amount);
                bool creditStatus = creditAccount.Deposit(amount);
                if (debitStatus && creditStatus)
                {
                    return true;
                }
                else
                {
                    debitAccount.Deposit(amount);
                    creditAccount.Withdraw(amount);
                    return false;
                }

            }
            catch (InvalidAmountException ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw new AccountTransactionException(ex.Message);
            }
            catch (InsufficientBalanceException ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw new AccountTransactionException(ex.Message);
            }
            catch (AccountTransactionException ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw ex;
            }
            catch (Exception ex)
            {
                Logger.Log(false, DateTime.Now, ex);
                throw new AccountTransactionException(ex.Message);
            }
        }

        private static Account GetAccountDetails(int accNo)
        {
            Account accountInfo = null;
            foreach (Account account in accounts)
            {
                if (account != null)
                {
                    if (account.AccountNumber == accNo)
                    {
                        accountInfo = account;
                        break;
                    }
                }
            }
            return accountInfo;
        }

        private static bool SaveAccount(Account account)
        {
            bool status = false;
            for (int i = 0; i < accounts.Length; i++)
            {
                if (accounts[i] == null)
                {
                    accounts[i] = account;
                    status = true;
                    break;
                }
            }
            return status;
        }

        private static bool AccountExists(int accountNumber)
        {
            foreach (Account account in accounts)
            {
                if (account != null)
                {
                    if (account.AccountNumber == accountNumber)
                        return true;
                }
            }

            return false;
        }
    }
}
