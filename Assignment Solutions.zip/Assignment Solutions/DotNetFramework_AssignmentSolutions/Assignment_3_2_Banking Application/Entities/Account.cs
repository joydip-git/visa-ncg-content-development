﻿using Assignment_3_2_Banking_Application.CustomExceptions;

namespace Assignment_3_2_Banking_Application.Entities
{
    public class Account
    {
        private int accountNumber;
        private string accountHolderName;
        private double currentBalance;

        public Account()
        {

        }

        public Account(int accountNumber, string accountHolderName, double currentBalance)
        {
            this.accountNumber = accountNumber;
            this.accountHolderName = accountHolderName;
            this.currentBalance = currentBalance;
        }

        public string AccountHolderName { get => accountHolderName; set => accountHolderName = value; }
        public double CurrentBalance { get => currentBalance; private set => currentBalance = value; }
        public int AccountNumber { get => accountNumber; set => accountNumber = value; }

        public bool Deposit(double depositAmount)
        {
            if (depositAmount <= 0)
                throw new InvalidAmountException("amount must be greater than 0");
            else
                this.currentBalance += depositAmount;

            return true;
        }
        public bool Withdraw(double withdrawalAmount)
        {
            if (withdrawalAmount <= 0)
                throw new InvalidAmountException("amount must be greater than 0");
            else if (withdrawalAmount > this.currentBalance)
                throw new InsufficientBalanceException("you don't have sufficient balance to withdraw");
            else
                this.currentBalance -= withdrawalAmount;

            return true;
        }
    }
}
