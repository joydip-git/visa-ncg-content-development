﻿using Assignment_3_2_Banking_Application.CustomExceptions;
using Assignment_3_2_Banking_Application.Entities;
using System;

namespace Assignment_3_2_Banking_Application
{
    class Program
    {
        static void Main()
        {
            try
            {
                for (int i = 0; i < 2; i++)
                {
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Number: ");
                    int accNumber = int.Parse(Console.ReadLine());
                    Console.Write("Initial Balance: ");
                    double balance = double.Parse(Console.ReadLine());
                    BankService.CreateAccount(name: name, initialBalance: balance, accountNumber: accNumber);
                }

                Console.Write("Enter Your(Debit) Account No: ");
                int debitAcc = int.Parse(Console.ReadLine());

                Console.Write("Enter Payee(Credit) Account No: ");
                int creditAcc = int.Parse(Console.ReadLine());

                Console.Write("Enter Amount to transfer: ");
                double amount = double.Parse(Console.ReadLine());

                bool status = BankService.TransferFund(debitAcc, creditAcc, amount);
                if (status)
                    Console.WriteLine("Transaction is successful.");

            }
            catch (AccountCreationException ex)
            {
                Console.WriteLine($"Account could not be created because:\n{ex.Message}");
            }
            catch (AccountTransactionException ex)
            {
                Console.WriteLine($"Transaction aborted because:\n{ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
