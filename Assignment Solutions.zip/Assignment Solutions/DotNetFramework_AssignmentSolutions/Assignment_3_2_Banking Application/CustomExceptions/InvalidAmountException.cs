﻿using System;

namespace Assignment_3_2_Banking_Application.CustomExceptions
{
    public class InvalidAmountException : ApplicationException
    {
        public InvalidAmountException()
        {

        }
        public InvalidAmountException(string errorMessage) : base(errorMessage)
        {

        }
    }
}
