﻿using System;

namespace Assignment_3_2_Banking_Application.CustomExceptions
{
    public class AccountTransactionException : ApplicationException
    {
        public AccountTransactionException()
        {

        }
        public AccountTransactionException(string errorMessage) : base(errorMessage)
        {

        }
    }
}
