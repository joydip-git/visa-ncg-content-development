﻿using System;

namespace Assignment_3_2_Banking_Application.CustomExceptions
{
    public class InsufficientBalanceException : ApplicationException
    {
        private string errorMessage;
        public InsufficientBalanceException()
        {

        }
        public InsufficientBalanceException(string errorMessage)
        {
            this.errorMessage = errorMessage;
        }

        public override string Message => this.errorMessage;
    }
}
