﻿using System;

namespace Assignment_3_2_Banking_Application.CustomExceptions
{
    public class AccountCreationException : ApplicationException
    {
        public AccountCreationException()
        {

        }
        public AccountCreationException(string errorMessage) : base(errorMessage)
        {

        }
    }
}
