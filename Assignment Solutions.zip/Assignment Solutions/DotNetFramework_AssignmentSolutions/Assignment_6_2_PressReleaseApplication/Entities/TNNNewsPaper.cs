﻿using System;

namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public class TNNNewsPaper
    {
        public event PressRelease WorldNews;
        public event PressRelease NationalNews;

        private void OnWorldNews(PressReport report)
        {
            if (WorldNews != null)
            {
                WorldNews(this, new PressReleaseEventArgs(report));
            }
        }

        private void OnNationalNews(PressReport report)
        {
            if (NationalNews != null)
            {
                WorldNews(this, new PressReleaseEventArgs(report));
            }
        }

        public void GetNews(NewsType newsType)
        {
            switch (newsType)
            {
                case NewsType.WorldNews:
                    OnWorldNews(new PressReport("World Report"));
                    break;
                case NewsType.NationalNews:
                    OnNationalNews(new PressReport("National Report"));
                    break;
                default:
                    Console.WriteLine("choose a news type properly");
                    break;
            }
        }
    }
}
