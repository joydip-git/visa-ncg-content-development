﻿using System;

namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public class PressReleaseEventArgs : EventArgs
    {
        private PressReport report;

        public PressReleaseEventArgs()
        {

        }
        public PressReleaseEventArgs(PressReport report)
        {
            this.report = report;
        }

        public PressReport Report
        {
            get { return report; }
            set { report = value; }
        }
    }
}
