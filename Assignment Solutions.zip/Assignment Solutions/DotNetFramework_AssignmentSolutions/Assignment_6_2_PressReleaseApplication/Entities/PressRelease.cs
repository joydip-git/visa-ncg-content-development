﻿namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public delegate void PressRelease(object sender, PressReleaseEventArgs args);
}
