﻿namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public enum NewsType
    {
        WorldNews,
        NationalNews
    }
}
