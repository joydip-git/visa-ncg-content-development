﻿namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public class PressReport
    {
        string newsReport;
        public PressReport()
        {

        }

        public PressReport(string newsReport)
        {
            this.newsReport = newsReport;
        }

        public string NewsReport { get => newsReport; set => newsReport = value; }
    }
}
