﻿using System;

namespace Assignment_6_2_PressReleaseApplication.Entities
{
    public class Subscriber
    {
        private TNNNewsPaper newsPaper;

        public Subscriber()
        {

        }
        public Subscriber(TNNNewsPaper newsPaper)
        {
            this.newsPaper = newsPaper;
        }

        public TNNNewsPaper NewsPaper { get => newsPaper; set => newsPaper = value; }

        public void SubscribeForNews(NewsType newsType)
        {
            switch (newsType)
            {
                case NewsType.WorldNews:
                    this.newsPaper.WorldNews += NewsPaper_WorldNews;
                    break;
                case NewsType.NationalNews:
                    this.newsPaper.NationalNews += NewsPaper_NationalNews;
                    break;
                default:
                    break;
            }
        }

        private void NewsPaper_WorldNews(object sender, PressReleaseEventArgs args)
        {
            Console.WriteLine(args.Report.NewsReport);
        }

        private void NewsPaper_NationalNews(object sender, PressReleaseEventArgs args)
        {
            Console.WriteLine(args.Report.NewsReport);
        }
    }








}
