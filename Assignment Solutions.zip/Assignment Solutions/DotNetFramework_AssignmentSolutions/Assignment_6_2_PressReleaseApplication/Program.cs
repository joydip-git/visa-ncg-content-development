﻿using Assignment_6_2_PressReleaseApplication.Entities;

namespace Assignment_6_2_PressReleaseApplication
{
    class Program
    {
        static void Main()
        {
            Subscriber anilSubscriber = new Subscriber(new TNNNewsPaper());
            anilSubscriber.SubscribeForNews(NewsType.NationalNews);
            anilSubscriber.SubscribeForNews(NewsType.WorldNews);
            
            anilSubscriber.NewsPaper.GetNews(NewsType.NationalNews);
            anilSubscriber.NewsPaper.GetNews(NewsType.WorldNews);
        }
    }
}
