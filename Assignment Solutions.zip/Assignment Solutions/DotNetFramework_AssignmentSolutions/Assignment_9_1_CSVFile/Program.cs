﻿using Assignment_9_1_CSVFile.DAO;
using System;

namespace Assignment_9_1_CSVFile
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductDao dao = new ProductDao();
            //view
            var products = dao.GetProducts();
            products.ForEach(p => Console.WriteLine(p));
            
            //update price
            products.ForEach(p =>
            {
                p.Price += (p.Price * 0.1);
            });
            //update in the file
            dao.UpdateProduct(products);
            //check
            products = dao.GetProducts();
            products.ForEach(p => Console.WriteLine(p));
        }
    }
}
