﻿using Assignment_9_1_CSVFile.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Assignment_9_1_CSVFile.DAO
{
    public class ProductDao
    {
        string filePath = @"..\..\Products.txt";

        public List<Product> GetProducts()
        {
            List<Product> products = null;

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    products = new List<Product>();
                    if (!reader.EndOfStream)
                    {
                        string data = null;
                        while ((data = reader.ReadLine()) != null)
                        {
                            //var separators = data.Where(ch => !char.IsLetterOrDigit(ch) && ch != '.').Distinct();
                            string[] record = data.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                            Product product = null;
                            ConvertRecordToProduct(record, ref product);
                            if (product != null)
                            {
                                products.Add(product);
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
            catch (IOException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return products;
        }

        public void UpdateProduct(List<Product> products)
        {
            if (products != null && products.Count > 0)
            {
                try
                {
                    using (StreamWriter writer = File.CreateText(filePath))
                    {
                        products.ForEach(p =>
                        {
                            writer.WriteLine(p.ToString());
                        });
                        writer.Flush();
                    }
                }
                catch (NullReferenceException ex)
                {
                    throw ex;
                }
                catch (FileNotFoundException ex)
                {
                    throw ex;
                }
                catch (IOException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        private void ConvertRecordToProduct(string[] record, ref Product product)
        {
            product = new Product { ProductId = int.Parse(record[0]), BrandName = record[1], Price = double.Parse(record[2]) };
        }
    }
}
