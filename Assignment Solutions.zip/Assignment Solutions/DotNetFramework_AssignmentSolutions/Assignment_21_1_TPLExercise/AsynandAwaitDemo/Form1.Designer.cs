﻿namespace AsynandAwaitDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.cmdParallelAsync = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(80, 94);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(474, 336);
            this.richTextBox3.TabIndex = 5;
            this.richTextBox3.Text = "";
            // 
            // cmdParallelAsync
            // 
            this.cmdParallelAsync.Location = new System.Drawing.Point(261, 30);
            this.cmdParallelAsync.Name = "cmdParallelAsync";
            this.cmdParallelAsync.Size = new System.Drawing.Size(168, 42);
            this.cmdParallelAsync.TabIndex = 4;
            this.cmdParallelAsync.Text = "Parallel Asynchronous Execution";
            this.cmdParallelAsync.UseVisualStyleBackColor = true;
            this.cmdParallelAsync.Click += new System.EventHandler(this.cmdParallelAsync_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 527);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.cmdParallelAsync);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Button cmdParallelAsync;
    }
}

