﻿using Assignment_18_1_ThreadSynchronizationExercise.CustomExceptions;
using Assignment_18_1_ThreadSynchronizationExercise.Entities;
using System.Threading;

namespace Assignment_18_1_ThreadSynchronizationExercise.Manager
{
    public class TransactionDetails
    {
        public double Amount { get; set; }
        public Account Account { get; set; }
    }
    public class Transaction
    {
        public void Deposit(object obj)
        {
            System.Console.WriteLine($"You are now depositing amount. Thread Id:{Thread.CurrentThread.ManagedThreadId}");

            TransactionDetails details = obj as TransactionDetails;
            //check whether control leaves this method or not, by suspending the thread...
            //Thread.Sleep(2000);
            Account.AccountMutex.WaitOne();
            if (details.Amount <= 0)
                throw new InvalidAmountException("amount must be greater than 0");
            else
                details.Account.CurrentBalance += details.Amount;

            System.Console.WriteLine($"Amount successfully Deposited. Current Balance:{details.Account.CurrentBalance}");

            Account.AccountMutex.ReleaseMutex();
        }
        public void Withdraw(object obj)
        {
            System.Console.WriteLine($"You are now withdrawing amount. Thread Id:{Thread.CurrentThread.ManagedThreadId}");

            TransactionDetails details = obj as TransactionDetails;

            Account.AccountMutex.WaitOne();
            if (details.Amount <= 0)
                throw new InvalidAmountException("amount must be greater than 0");
            else if (details.Amount > details.Account.CurrentBalance)
                throw new InsufficientBalanceException("you don't have sufficient balance to withdraw");
            else
                details.Account.CurrentBalance -= details.Amount;

            System.Console.WriteLine($"Amount successfully withdrawn. Current Balance:{details.Account.CurrentBalance}");

            Account.AccountMutex.ReleaseMutex();
        }
    }
}
