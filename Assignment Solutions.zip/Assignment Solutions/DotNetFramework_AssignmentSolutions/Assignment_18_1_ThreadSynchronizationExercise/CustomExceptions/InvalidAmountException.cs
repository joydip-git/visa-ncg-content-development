﻿using System;

namespace Assignment_18_1_ThreadSynchronizationExercise.CustomExceptions
{
    public class InvalidAmountException : ApplicationException
    {
        public InvalidAmountException()
        {

        }
        public InvalidAmountException(string errorMessage) : base(errorMessage)
        {

        }
    }
}
