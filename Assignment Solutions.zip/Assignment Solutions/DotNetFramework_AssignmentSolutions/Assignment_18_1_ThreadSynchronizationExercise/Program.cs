﻿using Assignment_18_1_ThreadSynchronizationExercise.Entities;
using Assignment_18_1_ThreadSynchronizationExercise.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignment_18_1_ThreadSynchronizationExercise
{
    class Program
    {
        static void Main()
        {
            Account account = new Account(1000, "anil", 1000);

            Transaction transaction = new Transaction();

            Thread withdrawalThread = new Thread(new ParameterizedThreadStart(transaction.Withdraw));
            Thread depositThread = new Thread(new ParameterizedThreadStart(transaction.Deposit));

            withdrawalThread.Start(new TransactionDetails { Amount = 500, Account = account });
            depositThread.Start(new TransactionDetails { Amount = 1000, Account = account });
        }
    }
}
