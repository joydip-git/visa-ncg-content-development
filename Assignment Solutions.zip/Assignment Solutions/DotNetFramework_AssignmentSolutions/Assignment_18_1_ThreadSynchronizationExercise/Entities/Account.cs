﻿using System.Threading;

namespace Assignment_18_1_ThreadSynchronizationExercise.Entities
{
    public class Account
    {
        private int accountNumber;
        private string accountHolderName;
        private double currentBalance;
        public static Mutex AccountMutex = new Mutex();

        public Account()
        {

        }

        public Account(int accountNumber, string accountHolderName, double currentBalance)
        {
            this.accountNumber = accountNumber;
            this.accountHolderName = accountHolderName;
            this.currentBalance = currentBalance;
        }

        public string AccountHolderName { get => accountHolderName; set => accountHolderName = value; }
        public double CurrentBalance { get => currentBalance; set => currentBalance = value; }
        public int AccountNumber { get => accountNumber; set => accountNumber = value; }        
    }
}
