﻿using Assignment1_1_Payroll_Application.Entities;
using System;

namespace Assignment1_1_Payroll_Application
{
    class Program
    {
        static void Main()
        {
            Employee[] employees = new Employee[4];

            PrintChoices();

            int choice = GetChoice();

            Employee employee;
            for (int i = 0; i < employees.Length; i++)
            {
                CreateEmployee(choice, out employee);
                employees[i] = employee;
            }

            PrintSalary(employees);
        }

        private static void PrintSalary(Employee[] employees)
        {
            if (employees != null && employees.Length > 0)
            {
                foreach (Employee employee in employees)
                {
                    if (employee != null)
                    {
                        employee.CalculateSalary();
                        //Console.WriteLine($"\nSalary of {employee.Name} is {employee.TotalSalary}");
                        //Console.WriteLine("\nSalary of {0} is {1}", employee.Name, employee.TotalSalary);
                        Console.WriteLine("\nSalary of " + employee.Name + " is " + employee.TotalSalary);
                    }
                }
            }
        }

        private static void CreateEmployee(int choice, out Employee employee)
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Basic Payment: ");
            decimal basicPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Da Payment: ");
            decimal daPayment = decimal.Parse(Console.ReadLine());

            Console.Write("Hra Payment: ");
            decimal hraPayment = decimal.Parse(Console.ReadLine());


            switch (choice)
            {
                case 1:
                    Console.Write("Incentive Payment: ");
                    decimal incentivePayment = decimal.Parse(Console.ReadLine());
                    employee = new Developer(name, id, basicPayment, daPayment, hraPayment, incentivePayment);
                    break;

                case 2:
                    Console.Write("Gratuity Payment: ");
                    decimal gratuityPayment = decimal.Parse(Console.ReadLine());
                    employee = new Hr(name, id, basicPayment, daPayment, hraPayment, gratuityPayment);
                    break;

                default:
                    Console.WriteLine("\nEnter proper choice\n");
                    employee = null;
                    break;
            }
        }

        private static int GetChoice()
        {
            Console.Write("\nEnter Choice[1/2]: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        private static void PrintChoices()
        {
            Console.WriteLine("1. Create Developer");
            Console.WriteLine("2. Create Hr");
        }
    }
}
