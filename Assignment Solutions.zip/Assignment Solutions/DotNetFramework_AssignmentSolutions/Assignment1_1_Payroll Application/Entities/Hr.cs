﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_1_Payroll_Application.Entities
{
    public class Hr:Employee
    {
        decimal gratuityPayment;

        public Hr()
        {

        }
        public Hr(string name = null, int id = 0, decimal basicPayment = 0, decimal hraPayment = 0, decimal daPayment = 0, decimal gratuityPayment = 0) : base(name, id, basicPayment, hraPayment, daPayment)
        {
            this.gratuityPayment = gratuityPayment;
        }

        public decimal GratuityPayment { get => gratuityPayment; set => gratuityPayment = value; }

        public override void CalculateSalary()
        {
            base.CalculateSalary();
            this.TotalSalary = this.TotalSalary + this.gratuityPayment;
        }
    }
}
