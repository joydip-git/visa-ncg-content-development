﻿namespace Assignment1_1_Payroll_Application.Entities
{
    public class Developer : Employee
    {
        decimal incentivePayment;

        public Developer()
        {

        }
        public Developer(string name = null, int id = 0, decimal basicPayment = 0, decimal hraPayment = 0, decimal daPayment = 0, decimal incentivePayment = 0) : base(name, id, basicPayment, hraPayment, daPayment)
        {
            this.incentivePayment = incentivePayment;
        }

        public decimal IncentivePayment { get => incentivePayment; set => incentivePayment = value; }

        public override void CalculateSalary()
        {
            base.CalculateSalary();
            this.TotalSalary = this.TotalSalary + this.incentivePayment;
        }
    }
}
