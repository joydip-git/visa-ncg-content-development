﻿namespace Assignment_2_2_ShapeAreaApplication.Entities
{
    public interface IShape
    {
        void CalculateArea();
        double Area { get; }
    }
}
