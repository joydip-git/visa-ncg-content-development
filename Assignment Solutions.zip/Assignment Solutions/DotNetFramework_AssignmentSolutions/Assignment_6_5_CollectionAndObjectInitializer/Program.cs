﻿using Assignment_6_5_CollectionAndObjectInitializer.Entities;
using System;
using System.Collections.Generic;

namespace Assignment_6_5_CollectionAndObjectInitializer
{
    class Program
    {
        static void Main()
        {
            List<Employee> employees = new List<Employee>
            {
                CreateEmployee(),
                CreateEmployee(),
                CreateEmployee()
            };

            foreach (var employee in employees)
            {
                Console.WriteLine($"Salary of {employee.Name} is {employee.CalculateSalary()}");
            }
        }

        private static Employee CreateEmployee()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Basic: ");
            double basic = double.Parse(Console.ReadLine());

            Console.Write("Da: ");
            double da = double.Parse(Console.ReadLine());

            Console.Write("Hra: ");
            double hra = double.Parse(Console.ReadLine());

            return new Employee { Name = name, Id = id, BasicPayment = basic, DaPayment = da, HraPayment = hra };
        }
    }
}
