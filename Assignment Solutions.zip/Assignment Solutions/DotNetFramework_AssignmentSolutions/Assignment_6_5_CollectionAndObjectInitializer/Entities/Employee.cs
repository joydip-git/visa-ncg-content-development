﻿namespace Assignment_6_5_CollectionAndObjectInitializer.Entities
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double BasicPayment { get; set; }
        public double DaPayment { get; set; }
        public double HraPayment { get; set; }

        public Employee()
        {

        }
        public Employee(int id, string name, double basicPayment, double daPayment, double hraPayment)
        {
            Id = id;
            Name = name;
            BasicPayment = basicPayment;
            DaPayment = daPayment;
            HraPayment = hraPayment;
        }

        public double CalculateSalary()
        {
            return this.BasicPayment + this.DaPayment + this.HraPayment;
        }
    }
}
