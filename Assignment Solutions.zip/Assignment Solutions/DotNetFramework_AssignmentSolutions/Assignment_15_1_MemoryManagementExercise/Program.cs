﻿using Assignment_15_1_MemoryManagementExercise.DAO;
using System;

namespace Assignment_15_1_MemoryManagementExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ProductDao dao = new ProductDao())
            {
                //view
                var products = dao.GetProducts();
                products.ForEach(p => Console.WriteLine(p));
            }
        }
    }
}
