﻿using Assignment_15_1_MemoryManagementExercise.Entities;
using System;
using System.Collections.Generic;
using System.IO;

namespace Assignment_15_1_MemoryManagementExercise.DAO
{
    public class ProductDao : IDisposable
    {
        string filePath = @"..\..\Products.txt";
        StreamReader reader;

        public ProductDao()
        {

        }
        ~ProductDao()
        {
            DisposeReader();
        }
        private void DisposeReader()
        {
            if (reader != null)
            {
                reader.Close();
                reader.Dispose();
            }
        }
        public void Dispose()
        {
            Console.WriteLine("Dispose called...reader will be disposed..");
            GC.SuppressFinalize(this);
            DisposeReader();
            reader = null;
        }

        public List<Product> GetProducts()
        {
            List<Product> products = null;

            try
            {
                if (File.Exists(filePath))
                {
                    reader = new StreamReader(filePath);
                    products = new List<Product>();
                    if (!reader.EndOfStream)
                    {
                        string data = null;
                        while ((data = reader.ReadLine()) != null)
                        {
                            //var separators = data.Where(ch => !char.IsLetterOrDigit(ch) && ch != '.').Distinct();
                            string[] record = data.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                            Product product = null;
                            ConvertRecordToProduct(record, ref product);
                            if (product != null)
                            {
                                products.Add(product);
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
            catch (IOException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return products;
        }

        private void ConvertRecordToProduct(string[] record, ref Product product)
        {
            product = new Product { ProductId = int.Parse(record[0]), BrandName = record[1], Price = double.Parse(record[2]) };
        }
    }
}
