﻿namespace CalculationLibrary
{
    public interface ICalculation
    {
        int Add(int x, int y);
        int Subtract(int x, int y);
    }
}