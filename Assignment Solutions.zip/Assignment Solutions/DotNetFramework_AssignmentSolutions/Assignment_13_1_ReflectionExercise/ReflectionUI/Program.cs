﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"E:\Visa\Assignment Solutions\DotNetFramework_AssignmentSolutions\Assignment_13_1_ReflectionExercise\CalculationLibrary\bin\Debug\CalculationLibrary.dll";
            if (File.Exists(filePath))
            {
                Assembly loadedAssembly = Assembly.LoadFile(filePath);
                Console.WriteLine($"Assembly Details: {loadedAssembly.FullName}");

                ShowTypes(loadedAssembly);

                Type calculationType = loadedAssembly.GetType("CalculationLibrary.Calculation");

                object calculationObject = Activator.CreateInstance(calculationType);

                ExtractMethodsOfCalculation(calculationType);

                ExtractMethodInfoAndInvoke("Add", calculationType, calculationObject);
                ExtractMethodInfoAndInvoke("Subtract", calculationType, calculationObject);
            }
        }

        private static void ExtractMethodInfoAndInvoke(string methodName, Type calculationType, object calculationObject)
        {
            MethodInfo methodInfo = calculationType.GetMethod(methodName);
            ParameterInfo[] allParams = methodInfo.GetParameters();
            DisplayParameterInfo(allParams);
            if (allParams != null && allParams.Length > 0)
            {
                Object[] parameters = new object[allParams.Length];
                parameters[0] = 100;
                parameters[1] = 20;

                object result = methodInfo.Invoke(calculationObject, parameters);
                Console.WriteLine($"\nResult of {methodInfo.Name} method is {result}");
            }
        }

        private static void DisplayParameterInfo(ParameterInfo[] allParams)
        {
            foreach (ParameterInfo parameter in allParams)
            {
                Console.WriteLine($"\nName: {parameter.Name}");
                Console.WriteLine($"Position: {parameter.Position}");
                Console.WriteLine($"Type: {parameter.ParameterType}");
                Console.WriteLine($"Is Out? {parameter.IsOut}");
                Console.WriteLine($"Opional? {parameter.IsOptional}");
            }
        }

        private static void ExtractMethodsOfCalculation(Type calculationType)
        {
            var methodList = calculationType.GetMethods().ToList<MethodInfo>();
            methodList.ForEach(method =>
            {
                Console.WriteLine($"\nName: {method.Name}");
                Console.WriteLine($"Abstract? {method.IsAbstract}");
                Console.WriteLine($"Static? {method.IsStatic}");
                Console.WriteLine($"Return Type: {method.ReturnType}");
            });
        }

        private static void ShowTypes(Assembly loadedAssembly)
        {
            var allTypes = loadedAssembly.GetTypes().ToList<Type>();
            allTypes.ForEach(type =>
            {
                Console.WriteLine($"\nName: {type.Name}");
                Console.WriteLine($"Is Interface: {type.IsInterface}");
                Console.WriteLine($"Is Class: {type.IsClass}");
                Console.WriteLine($"Is Structure: {type.IsValueType}");
                Console.WriteLine($"Is Enum: {type.IsEnum}");
                Console.WriteLine($"\nMembers of {type.Name}\n");
                type.GetMembers().ToList<MemberInfo>().ForEach(member =>
                {
                    Console.WriteLine($"\nMember Name: {member.Name}");
                    Console.WriteLine($"Member Type: {member.MemberType}");
                });
            });
        }
    }
}
