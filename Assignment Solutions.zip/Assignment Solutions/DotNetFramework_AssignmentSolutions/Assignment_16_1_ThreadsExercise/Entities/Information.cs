﻿using System.Collections.Generic;

namespace Assignment_16_1_ThreadsExercise.Entities
{
    public class Information
    {
        public string FilePath { get; set; }
        public List<Product> Data { get; set; }
    }
}
