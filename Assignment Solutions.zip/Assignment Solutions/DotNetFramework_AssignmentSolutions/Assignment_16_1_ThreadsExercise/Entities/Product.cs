﻿using System;

namespace Assignment_16_1_ThreadsExercise.Entities
{
    public class Product : IComparable<Product>
    {
        string brandName;
        int productId;
        double price;

        public Product()
        {

        }

        public Product(string brandName, int productId, double price)
        {
            this.brandName = brandName;
            this.productId = productId;
            this.price = price;
        }

        public string BrandName { get => brandName; set => brandName = value; }
        public int ProductId { get => productId; set => productId = value; }
        public double Price { get => price; set => price = value; }

        public int CompareTo(Product other)
        {
            if (other != null)
            {
                return this.productId.CompareTo(other.productId);
            }
            else
                throw new NullReferenceException("the argyment passed in null");
        }

        public override string ToString()
        {
            return $"{this.ProductId}, {this.BrandName}, {this.Price}";
        }
    }
}
