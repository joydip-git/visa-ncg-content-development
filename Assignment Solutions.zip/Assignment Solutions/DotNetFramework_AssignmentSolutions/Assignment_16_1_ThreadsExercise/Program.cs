﻿using Assignment_16_1_ThreadsExercise.DAO;
using Assignment_16_1_ThreadsExercise.Entities;
using System.Collections.Generic;
using System.Threading;

namespace Assignment_16_1_ThreadsExercise
{
    class Program
    {
        static void Main()
        {
            string filePath = @"..\..\Products.txt";
            ProductDao productDao = new ProductDao();

            Thread fetchDataThread = new Thread(new ParameterizedThreadStart(productDao.GetProducts));
            fetchDataThread.Name = "ReadThread";

            Thread writeDataThread = new Thread(new ParameterizedThreadStart(productDao.UpdateProduct));
            writeDataThread.Name = "WriteThread";

            var info = new Information
            {
                Data = new List<Product>
                {
                    new Product("Dell Laptop", 100, 45000.00),
                    new Product("Logitech Mouse", 101, 500.00),
                    new Product("Windows 7",102,7000.00)

                },
                FilePath = filePath
            };
            writeDataThread.Start(info);
            writeDataThread.Join();

            fetchDataThread.Start(new Information { Data = null, FilePath = filePath });
            fetchDataThread.Join();

        }
    }
}
