﻿using EmployeeLibrary;
using System;

namespace HRMSUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee("anil", 1, 1000, 2000, 3000);
            employee.CalculateSalary();
            Console.WriteLine(employee.TotalSalary);
        }
    }
}
