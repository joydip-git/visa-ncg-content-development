﻿namespace EmployeeLibrary
{
    public class Employee
    {
        #region Data Members
        string name;
        int id;
        decimal basicPayment;
        decimal hraPayment;
        decimal daPayment;
        decimal totalSalary;
        #endregion

        #region Constructors
        public Employee(string name = null, int id = 0, decimal basicPayment = 0, decimal hraPayment = 0, decimal daPayment = 0)
        {
            this.name = name;
            this.id = id;
            this.basicPayment = basicPayment;
            this.hraPayment = hraPayment;
            this.daPayment = daPayment;
        }

        #endregion

        #region Properties
        public string Name { get => name; set => name = value; }
        public int Id { get => id; set => id = value; }
        public decimal BasicPayment { get => basicPayment; set => basicPayment = value; }
        public decimal HraPayment { get => hraPayment; set => hraPayment = value; }
        public decimal DaPayment { get => daPayment; set => daPayment = value; }
        public decimal TotalSalary { get => totalSalary; protected set => totalSalary = value; }
        #endregion

        #region Methods
        public virtual void CalculateSalary()
        {
            this.totalSalary = this.basicPayment + this.daPayment + this.hraPayment;
        }
        #endregion
    }
}
