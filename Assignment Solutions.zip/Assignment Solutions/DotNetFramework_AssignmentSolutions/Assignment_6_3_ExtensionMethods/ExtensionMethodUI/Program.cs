﻿using CalculationExtensionLibrary;
using CalculationLibrary;
using System;

namespace ExtensionMethodUI
{
    class Program
    {
        static void Main()
        {
            Calculation calc = new Calculation();
            //original methods
            Console.WriteLine(calc.Add(12, 13));
            Console.WriteLine(calc.Subtract(12,3));
            //extension methods
            Console.WriteLine(calc.Multiply(12,3));
            Console.WriteLine(calc.Divide(12, 3));
        }
    }
}
