﻿using CalculationLibrary;
using System;

namespace CalculationExtensionLibrary
{
    public static class CalculationExtension
    {
        public static int Multiply(this Calculation calculation, int x, int y)
        {
            return (x * y);
        }
        public static int Divide(this Calculation calculation, int x, int y)
        {
            if (y > 0)
            {
                return (x / y);
            }
            else
                throw new DivideByZeroException($"can't divide {x} by {y}...");
        }
    }
}
