﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_1_3._1_HandlingRuntimeExceptions
{
    class Program
    {
        static void SetIndexAndDivisor(string[] args, ref int? index, ref int? divisor, ref int[] numbers)
        {
            try
            {
                switch (args.Length)
                {
                    case 0:
                        index = null;
                        divisor = null;
                        break;

                    case 1:
                        index = 0;
                        divisor = int.Parse(args[0]);
                        break;

                    case 2:
                        index = int.Parse(args[0]);
                        divisor = int.Parse(args[1]);
                        break;

                    default:
                        index = int.Parse(args[args.Length - 2]);
                        divisor = int.Parse(args[args.Length - 1]);
                        numbers = new int[args.Length - 2];
                        for (int i = 0; i < args.Length - 2; i++)
                        {
                            numbers[i] = int.Parse(args[i]);
                        }
                        break;
                }
            }
            catch (FormatException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        static void Main(string[] args)
        {
            int? index = null;
            int? divisor = null;
            int[] numbers = null;
            int? divisionResult = null;

            try
            {
                SetIndexAndDivisor(args, ref index, ref divisor, ref numbers);
                divisionResult = DivideAndPrint(index, divisor, numbers);
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine(ex);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                if (!divisionResult.HasValue)
                {
                    Console.WriteLine("no division result was possible to display because of the above mentioned issues");
                }
            }
        }

        private static int? DivideAndPrint(int? index, int? divisor, int[] numbers)
        {
            int? divisionResult;
            if (numbers != null)
            {
                if (index.HasValue)
                {
                    if (index.Value < numbers.Length)
                    {
                        if (divisor.HasValue)
                        {
                            if (divisor.Value > 0)
                            {
                                int number = numbers[index.Value];
                                divisionResult = number / divisor;
                                Console.WriteLine($"Division of {number} by {divisor} is {divisionResult}");
                            }
                            else
                            {
                                throw new DivideByZeroException("Divisor can't be zero");
                            }
                        }
                        else
                        {
                            throw new ArgumentNullException("No Divisor value was supplied...");
                        }
                    }
                    else
                    {
                        throw new IndexOutOfRangeException($"The Index value:{index.Value} is outside the bound [{numbers.Length}] of the array..not possible to retrieve value");
                    }
                }
                else
                {
                    throw new ArgumentNullException("No Index value was supplied...");
                }
            }
            else
            {
                throw new NullReferenceException("Array of numbers was not passed...refernce is NULL");
            }

            return divisionResult;
        }
    }
}
