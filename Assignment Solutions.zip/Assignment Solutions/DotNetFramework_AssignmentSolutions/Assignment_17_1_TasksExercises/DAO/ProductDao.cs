﻿using Assignment_17_1_TasksExercises.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Assignment_17_1_TasksExercises.DAO
{
    public class ProductDao
    {
        public List<Product> GetProducts(object obj)
        {
            Console.WriteLine($"You are in Thread Id: {Thread.CurrentThread.ManagedThreadId}");

            Information information = obj as Information;
            List<Product> products = null;

            try
            {
                using (StreamReader reader = new StreamReader(information.FilePath))
                {
                    products = new List<Product>();
                    if (!reader.EndOfStream)
                    {
                        string data = null;
                        while ((data = reader.ReadLine()) != null)
                        {
                            //var separators = data.Where(ch => !char.IsLetterOrDigit(ch) && ch != '.').Distinct();
                            string[] record = data.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                            Product product = null;
                            ConvertRecordToProduct(record, ref product);
                            if (product != null)
                            {
                                products.Add(product);
                            }
                        }
                    }
                }
                return products;
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
            catch (IOException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (products != null && products.Count > 0)
            //    {
            //        products.ForEach(p => Console.WriteLine(p));
            //    }
            //    else
            //        Console.WriteLine("No products found...");
            //}
        }

        public void UpdateProduct(object obj)
        {
            Console.WriteLine($"You are in {Thread.CurrentThread.Name} and Id: {Thread.CurrentThread.ManagedThreadId}");

            Information information = obj as Information;
            List<Product> products = information.Data;
            string filePath = information.FilePath;
            if (products != null && products.Count > 0)
            {
                try
                {
                    using (StreamWriter writer = File.CreateText(filePath))
                    {
                        products.ForEach(p =>
                        {
                            writer.WriteLine(p.ToString());
                        });
                        writer.Flush();
                    }
                }
                catch (NullReferenceException ex)
                {
                    throw ex;
                }
                catch (FileNotFoundException ex)
                {
                    throw ex;
                }
                catch (IOException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    Console.WriteLine("completed writing operation...");
                }
            }
        }

        private void ConvertRecordToProduct(string[] record, ref Product product)
        {
            product = new Product { ProductId = int.Parse(record[0]), BrandName = record[1], Price = double.Parse(record[2]) };
        }
    }
}
