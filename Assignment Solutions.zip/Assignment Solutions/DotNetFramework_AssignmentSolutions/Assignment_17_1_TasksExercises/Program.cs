﻿using Assignment_17_1_TasksExercises.DAO;
using Assignment_17_1_TasksExercises.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Assignment_17_1_TasksExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"..\..\Products.txt";
            ProductDao productDao = new ProductDao();
            WriteProducts(filePath, productDao);
            ReadProducts(filePath, productDao);
        }

        private static void WriteProducts(string filePath, ProductDao productDao)
        {
            var info = new Information
            {
                Data = new List<Product>
                {
                    new Product("Dell Laptop", 100, 45000.00),
                    new Product("Logitech Mouse", 101, 500.00),
                    new Product("Windows 7",102,7000.00)

                },
                FilePath = filePath
            };
            Task.Factory.StartNew(() => productDao.UpdateProduct(info)).Wait();

        }

        static void ReadProducts(string filePath, ProductDao productDao)
        {
            var productsTask = Task<List<Product>>.Factory.StartNew(() => productDao.GetProducts(new Information { FilePath = filePath }));
            productsTask.Result.ForEach(p => Console.WriteLine(p));
            productsTask.Wait();
        }
    }
}
