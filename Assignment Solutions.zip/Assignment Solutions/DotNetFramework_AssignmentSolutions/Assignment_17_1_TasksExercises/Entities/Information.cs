﻿using System.Collections.Generic;

namespace Assignment_17_1_TasksExercises.Entities
{
    public class Information
    {
        public string FilePath { get; set; }
        public List<Product> Data { get; set; }
    }
}
