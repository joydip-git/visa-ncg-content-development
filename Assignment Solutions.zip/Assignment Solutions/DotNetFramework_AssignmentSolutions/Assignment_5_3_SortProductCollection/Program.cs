﻿using Assignment_5_3_SortProductCollection.Entities;
using Assignment_5_3_SortProductCollection.Manager;
using System;
using System.Collections.Generic;

namespace Assignment_5_3_SortProductCollection
{
    class Program
    {

        static void Main()
        {
            ShowMainMenu();

            int mainChoice = GetChoice();

            ProductManager manager = new ProductManager();
            switch (mainChoice)
            {
                case 1:
                    var defaultView = manager.GetProducts();
                    Display(defaultView);
                    break;

                case 2:
                    ShowProductSortMenu();
                    int sortChoice = GetChoice();
                    switch (sortChoice)
                    {
                        case 1:
                            var brandView = manager.GetProducts(SortOption.BrandName);
                            Display(brandView);
                            break;

                        case 2:
                            var priceView = manager.GetProducts(SortOption.Price);
                            Display(priceView);
                            break;

                        default:
                            Console.WriteLine("\nEnter Proper Choice for sorting");
                            break;
                    }
                    break;

                default:
                    Console.WriteLine("\nEnter Proper Choice");
                    break;
            }
        }

        private static void ShowProductSortMenu()
        {
            Console.WriteLine("1. Sort By Brand Name");
            Console.WriteLine("2. Sort By Price");
        }

        private static void Display(List<Product> products)
        {
            foreach (var item in products)
            {
                Console.WriteLine(item);
            }
        }

        private static int GetChoice()
        {
            Console.Write("Enter Choice[1/2]: ");
            return int.Parse(Console.ReadLine());
        }

        private static void ShowMainMenu()
        {
            Console.WriteLine("1. View Products");
            Console.WriteLine("2. Sort Products");
        }
    }
}
