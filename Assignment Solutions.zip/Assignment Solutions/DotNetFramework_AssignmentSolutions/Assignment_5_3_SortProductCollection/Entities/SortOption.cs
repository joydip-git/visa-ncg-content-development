﻿namespace Assignment_5_3_SortProductCollection.Entities
{
    public enum SortOption
    {
        BrandName = 1,
        Price = 2
    }
}