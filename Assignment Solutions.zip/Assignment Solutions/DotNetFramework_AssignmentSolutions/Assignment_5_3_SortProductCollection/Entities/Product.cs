﻿using System;

namespace Assignment_5_3_SortProductCollection.Entities
{
    public class Product : IComparable<Product>
    {
        string brandName;
        int productId;
        string description;
        double price;

        public Product()
        {

        }

        public Product(string brandName, int productId, string description, double price)
        {
            this.brandName = brandName;
            this.productId = productId;
            this.description = description;
            this.price = price;
        }

        public string BrandName { get => brandName; set => brandName = value; }
        public int ProductId { get => productId; set => productId = value; }
        public string Description { get => description; set => description = value; }
        public double Price { get => price; set => price = value; }

        public int CompareTo(Product other)
        {
            if (other != null)
            {
                return this.productId.CompareTo(other.productId);
            }
            else
                throw new NullReferenceException("the argyment passed in null");
        }

        public override string ToString()
        {
            return $"Id:{this.productId}, Name:{this.brandName}, Price:{this.price} and Description:{this.description}";
        }
    }
}
