﻿using Assignment_5_3_SortProductCollection.Entities;
using System.Collections.Generic;

namespace Assignment_5_3_SortProductCollection.Manager
{
    public class ProductComparer : IComparer<Product>
    {
        private SortOption _option;
        public ProductComparer(SortOption option)
        {
            _option = option;
        }
        public int Compare(Product x, Product y)
        {
            int result = 0;
            switch (_option)
            {
                case SortOption.BrandName:
                    result = x.BrandName.CompareTo(y.BrandName) != 0 ? x.BrandName.CompareTo(y.BrandName) : x.Description.CompareTo(y.BrandName);
                    break;

                case SortOption.Price:
                    result = x.Price.CompareTo(y.Price) != 0 ? x.Price.CompareTo(y.Price) : x.ProductId.CompareTo(y.ProductId);
                    break;

                default:
                    result = x.ProductId.CompareTo(y.ProductId);
                    break;
            }
            return result;
        }
    }
}
