﻿using Assignment_5_3_SortProductCollection.Entities;
using Assignment_5_3_SortProductCollection.Repository;
using System.Collections.Generic;

namespace Assignment_5_3_SortProductCollection.Manager
{
    public class ProductManager
    {
        private List<Product> products;
        public ProductManager()
        {
            products = ProductRepository.Products;
        }
        public List<Product> GetProducts()
        {            
            products.Sort();
            return products;
        }
        public List<Product> GetProducts(SortOption sortOption)
        {
            ProductComparer comparer = new ProductComparer(sortOption);
            products.Sort(comparer);
            return products;
        }
    }
}
