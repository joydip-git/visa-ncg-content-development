﻿using Assignment_5_3_SortProductCollection.Entities;
using System.Collections.Generic;

namespace Assignment_5_3_SortProductCollection.Repository
{
    public static class ProductRepository
    {
        private static List<Product> products;
        static ProductRepository()
        {
            products = new List<Product>();
            products.Add(new Product("Dell", 200, "15 inch Monitor", 3400.44));
            products.Add(new Product("Dell", 120, "Laptop", 45000.00));
            products.Add(new Product("Logitech", 100, "Optical Mouse", 540.00));
            products.Add(new Product("Microsoft", 150, "Windows 7", 7000.50));
        }

        public static List<Product> Products => products;
    }
}
