﻿using System.Collections.Generic;

namespace Assignment_5_2_SortStringByLength
{
    public class StringLengthComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            return x.Length.CompareTo(y.Length);
        }
    }
}
