﻿using System;
using System.Collections.Generic;

namespace Assignment_5_2_SortStringByLength
{
    class Program
    {
        static void Main()
        {
            int number = GetNumberOfStrings();

            List<string> strings = new List<string>();

            StoreStrings(number, strings);

            SortStringsByLength(strings);

            ShowStrings(strings);
        }

        private static void ShowStrings(List<string> strings)
        {
            foreach (string str in strings)
            {
                Console.WriteLine(str);
            }
        }

        private static void StoreStrings(int number, List<string> strings)
        {
            for (int i = 0; i < number; i++)
            {
                Console.Write("Enter a string: ");
                strings.Add(Console.ReadLine());
            }
        }

        private static int GetNumberOfStrings()
        {
            Console.Write("Number of strings: ");
            int number = int.Parse(Console.ReadLine());
            return number;
        }

        private static void SortStringsByLength(List<string> strings)
        {
            StringLengthComparer comparer = new StringLengthComparer();
            strings.Sort(comparer);
        }
    }
}
