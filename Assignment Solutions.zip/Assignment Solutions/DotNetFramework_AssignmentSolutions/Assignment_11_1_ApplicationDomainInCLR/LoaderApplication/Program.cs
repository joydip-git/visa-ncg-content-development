﻿using System;

namespace LoaderApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"\nLoader Application is running in: { AppDomain.CurrentDomain.FriendlyName}");

            AppDomain secondaryDomain = AppDomain.CreateDomain("secondary domain");
            secondaryDomain.AssemblyLoad += SecondaryDomain_AssemblyLoad;
            secondaryDomain.Load("LoadedApplication");
            secondaryDomain.ExecuteAssembly("LoadedApplication.exe");
        }

        private static void SecondaryDomain_AssemblyLoad(object sender, AssemblyLoadEventArgs args)
        {
            Console.WriteLine($"The assembly loaded in the {AppDomain.CurrentDomain.FriendlyName}  is {args.LoadedAssembly.FullName}");
        }
    }
}
