﻿using System;

namespace LoadedApplication
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine($"\nLoaded Application is running in: { AppDomain.CurrentDomain.FriendlyName}");
        }
    }
}
