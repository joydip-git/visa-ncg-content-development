﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace Assignment_8_2_LINQtoXML
{
    class Program
    {
        static void Main()
        {
            var filepath = @"..\..\data.xml";
            XElement doc = XElement.Load(filepath);
            
            var query = from e in doc.Descendants("employee")
                        where e.Attribute("salaried").Value == "yes"
                        select e.Element("name").Value;
            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }
    }
}
