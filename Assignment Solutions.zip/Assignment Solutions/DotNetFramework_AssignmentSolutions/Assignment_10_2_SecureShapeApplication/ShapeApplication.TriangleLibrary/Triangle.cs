﻿using ShapeApplication.ShapeLibrary;

namespace ShapeApplication.TriangleLibrary
{
    public class Triangle : IShape
    {
        double _triangleArea;
        double _tBase;
        double _tHeight;

        public Triangle()
        {

        }
        public Triangle(double tBase, double tHeight)
        {
            _tBase = tBase;
            _tHeight = tHeight;
        }

        public double Area => _triangleArea;
        public double TBase { get => _tBase; set => _tBase = value; }
        public double THeight { get => _tHeight; set => _tHeight = value; }

        public void CalculateArea()
        {
            _triangleArea = 0.5 * _tBase * _tHeight;
        }
    }
}
