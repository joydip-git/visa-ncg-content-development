﻿namespace ShapeApplication.ShapeLibrary
{
    public interface IShape
    {
        void CalculateArea();
        double Area { get; }
    }
}
