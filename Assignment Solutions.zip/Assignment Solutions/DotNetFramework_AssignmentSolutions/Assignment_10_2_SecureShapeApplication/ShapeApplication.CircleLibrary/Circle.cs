﻿using ShapeApplication.ShapeLibrary;
using System;

namespace ShapeApplication.CircleLibrary
{
    public class Circle : IShape
    {
        double _radius;
        double _circleArea;
        public Circle()
        {

        }
        public Circle(double radius)
        {
            _radius = radius;
        }

        public double Radius { get => _radius; set => _radius = value; }
        public double Area { get => _circleArea; }

        public void CalculateArea()
        {
            _circleArea = _radius * _radius * Math.PI;
        }
    }
}
