﻿using ShapeApplication.CircleLibrary;
using ShapeApplication.ShapeLibrary;
using ShapeApplication.TriangleLibrary;
using System;

namespace ShapeApplication.UI
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("1. Circle");
            Console.WriteLine("2. Triangle");

            Console.Write("\nEnter a choice[1/2]: ");
            int shapeChoice = int.Parse(Console.ReadLine());

            IShape shape = CreateShape(shapeChoice);
            CalculateAndPrintArea(shape);
        }

        private static IShape CreateShape(int shapeChoice)
        {
            IShape shape = null;
            switch (shapeChoice)
            {
                case 1:
                    Console.Write("\nEnter Radius of Circle: ");
                    double radius = double.Parse(Console.ReadLine());
                    shape = new Circle(radius);
                    break;

                case 2:
                    Console.Write("\nEnter Base of Triangle: ");
                    double tbase = double.Parse(Console.ReadLine());

                    Console.Write("Enter Height of Triangle: ");
                    double theight = double.Parse(Console.ReadLine());

                    shape = new Triangle(tbase, theight);
                    break;

                default:
                    Console.WriteLine("\nEnter proper choice\n");
                    break;
            }
            return shape;
        }

        private static void CalculateAndPrintArea(IShape shape)
        {
            if (shape != null)
            {
                shape.CalculateArea();
                Console.WriteLine($"\nArea of {shape.GetType().Name} is {shape.Area}");
            }
        }
    }
}
