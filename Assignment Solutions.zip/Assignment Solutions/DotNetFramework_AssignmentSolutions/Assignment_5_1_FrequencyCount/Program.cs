﻿using System;
using System.Collections.Generic;

namespace Assignment_5_1_FrequencyCount
{
    class Program
    {

        static void Main()
        {
            string input = GetSentence();
            //sample i/p: --> DotNet is technology and DotNet is interoperable and DotNet is simple
            try
            {
                SortedList<string, int> result = GetWordFrequencyCount(input);
                if (result != null)
                {
                    foreach (KeyValuePair<string, int> item in result)
                    {
                        Console.WriteLine(item.Key + ":" + item.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static SortedList<string, int> GetWordFrequencyCount(string input)
        {
            SortedList<string, int> wordStore = null;
            if (input != null && input != string.Empty)
            {
                wordStore = new SortedList<string, int>();

                HashSet<char> separators = GetSeparators(input);
                if (separators != null && separators.Count > 0)
                {
                    char[] separatorArray = new char[separators.Count];
                    separators.CopyTo(separatorArray);
                    string[] words = input.Split(separatorArray, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string word in words)
                    {
                        if (wordStore.ContainsKey(word))
                        {
                            wordStore[word] += 1;
                        }
                        else
                        {
                            wordStore.Add(word, 1);
                        }
                    }

                }
                else
                {
                    wordStore.Add(input, 1);
                }
            }
            else
            {
                throw new ArgumentException("sentence is either null or empty...");
            }
            return wordStore;
        }

        private static HashSet<char> GetSeparators(string input)
        {
            HashSet<char> separators = new HashSet<char>();
            foreach (char ch in input)
            {
                if (char.IsSeparator(ch) || !char.IsLetterOrDigit(ch) || char.IsWhiteSpace(ch))
                {
                    separators.Add(ch);
                }
            }
            return separators;
        }

        private static string GetSentence()
        {
            Console.Write("Enter a sentence: ");
            return Console.ReadLine();
        }
    }
}
