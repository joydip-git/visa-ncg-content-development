﻿using System;
using System.Linq;

namespace QuizEntityLibrary
{
    [Serializable]
    public class Option
    {
        public int OptionId { get; set; }
        public string OptionText { get; set; }
        public bool IsCorrect { get; set; }

        public Option()
        {

        }

        public Option(int optionId, string optionText, bool isCorrect)
        {
            OptionId = optionId;
            OptionText = optionText;
            IsCorrect = isCorrect;
        }        

        public override bool Equals(object obj)
        {
            Option option = obj as Option;
            if (this == option)
                return true;
            if (!this.OptionId.Equals(option.OptionId))
                return false;
            if (!this.OptionText.Equals(option.OptionText))
                return false;
            if (!this.IsCorrect.Equals(option.IsCorrect))
                return false;

            return true;
        }
        public override int GetHashCode()
        {
            int hash = 23;
            this.GetType().GetProperties().ToList().ForEach(p =>
            {
                hash = p.GetValue(this).GetHashCode() * hash;
            });
            return hash;
        }
    }
}
