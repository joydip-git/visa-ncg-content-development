﻿using System;
using System.Collections.Generic;

namespace QuizEntityLibrary
{
    [Serializable]
    public class Quiz
    {
        public int QuizId { get; set; }
        public DateTime QuizDate { get; set; }
        public string Description { get; set; }
        public HashSet<Question> Questions { get; set; }

        public Quiz()
        {

        }

        public Quiz(int quizId, DateTime quizDate, string description, HashSet<Question> questions)
        {
            QuizId = quizId;
            QuizDate = quizDate;
            Description = description;
            Questions = questions;
        }
        public override string ToString()
        {
            return $"Quiz: {this.Description}\nDate:{this.QuizDate}";
        }
    }
}
