﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace QuizEntityLibrary
{
    [Serializable]
    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public List<Option> Options { get; set; }

        public Question()
        {

        }

        public Question(int questionId, string questionText, List<Option> options)
        {
            QuestionId = questionId;
            QuestionText = questionText;
            Options = options;
        }

        public override bool Equals(object obj)
        {
            Question question = obj as Question;
            if (this == question)
                return true;
            if (!this.QuestionId.Equals(question.QuestionId))
                return false;
            if (!this.QuestionText.Equals(question.QuestionText))
                return false;
            if (!this.Options.Equals(question.Options))
                return false;

            return true;
        }
        public override int GetHashCode()
        {
            int hash = 23;
            this.GetType().GetProperties().ToList().ForEach(p =>
            {
                hash = p.GetValue(this).GetHashCode() * hash;
            });
            return hash;
        }
    }
}
