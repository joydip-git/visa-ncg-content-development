﻿using QuizEntityLibrary;
using System;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace QuizDeSerializer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string filePath = @"..\..\quizData.xml";
                object obj = DeSerializeQuize(filePath);
                if (obj is Quiz)
                {
                    Quiz quiz = obj as Quiz;
                    Console.WriteLine(quiz);
                    quiz.Questions.ToList<Question>().ForEach(q =>
                    {
                        Console.WriteLine($"Question{q.QuestionId}: {q.QuestionText}");
                        q.Options.ForEach(o =>
                        {
                            Console.WriteLine($"{o.OptionId}. {o.OptionText}" + (o.IsCorrect ? "(Correct)" : "(Not Correct)"));
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static object DeSerializeQuize(string filePath)
        {
            XmlSerializer xmlSerializer = null;
            FileStream fs = null;
            try
            {
                object deserializedObj = null;
                using (fs = new FileStream(filePath, FileMode.OpenOrCreate))
                {
                    xmlSerializer = new XmlSerializer(typeof(Quiz), new Type[] { typeof(Question), typeof(Option) });
                    deserializedObj = xmlSerializer.Deserialize(fs);
                }
                return deserializedObj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
