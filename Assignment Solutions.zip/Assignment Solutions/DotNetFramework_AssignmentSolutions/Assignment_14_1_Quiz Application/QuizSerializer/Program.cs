﻿using QuizEntityLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace QuizSerializer
{
    class Program
    {
        static void Main()
        {
            try
            {
                string filePath = @"..\..\quizData.xml";
                Quiz quiz = CreateQuiz();
                SerializeQuize(quiz, filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static void SerializeQuize(Quiz quiz, string filePath)
        {
            XmlSerializer xmlSerializer = null;
            FileStream fs = null;
            try
            {
                using (fs = new FileStream(filePath, FileMode.OpenOrCreate))
                {
                    xmlSerializer = new XmlSerializer(quiz.GetType(), new Type[] { typeof(Question), typeof(Option) });
                    xmlSerializer.Serialize(fs, quiz);                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static Quiz CreateQuiz()
        {
            Quiz dotnetQuiz = new Quiz
            {
                QuizId = 1,
                QuizDate = new DateTime(2020, 11, 7),
                Description = "Quiz on DotNet Framework",
                Questions = new HashSet<Question>
                {
                    new Question
                    {
                        QuestionId=1,
                        QuestionText="When DotNet Framework got introduced?",
                        Options= new List<Option>
                        {
                            new Option{ OptionId=1, OptionText="2020", IsCorrect=false},
                            new Option{ OptionId=2, OptionText="2000", IsCorrect=true},
                            new Option{ OptionId=3, OptionText="2010", IsCorrect=false}
                        }
                    },
                     new Question
                    {
                        QuestionId=2,
                        QuestionText="Which Company Came up with DotNet Framework?",
                        Options= new List<Option>
                        {
                            new Option{ OptionId=1, OptionText="Oracle", IsCorrect=false},
                            new Option{ OptionId=2, OptionText="Google", IsCorrect=false},
                            new Option{ OptionId=3, OptionText="Microsoft", IsCorrect=true}
                        }
                    }
                }
            };
            return dotnetQuiz;
        }
    }
}
