﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsynandAwaitDemo
{
    public class WebSiteDataModel
    {
        public string WebSiteUrl { get; set; }
        public string WebSiteData { get; set; }
    }
}
