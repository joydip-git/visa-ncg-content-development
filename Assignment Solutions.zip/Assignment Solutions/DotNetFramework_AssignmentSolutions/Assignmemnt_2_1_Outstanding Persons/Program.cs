﻿using Assignmemnt_2_1_Outstanding_Persons.Entities;
using System;

namespace Assignmemnt_2_1_Outstanding_Persons
{
    class Program
    {
        static void Main()
        {
            Person[] people = new Person[4];

            

            Person person;
            for (int i = 0; i < people.Length; i++)
            {
                PrintChoices();
                int choice = GetChoice();
                CreatePerson(choice, out person);
                people[i] = person;
            }

            PrintPerson(people);
        }

        private static void PrintPerson(Person[] people)
        {
            if (people != null && people.Length > 0)
            {
                foreach (Person person in people)
                {
                    if (person != null)
                    {
                        if (person.IsOutstanding())
                        {
                            if (person is Professor)
                                Console.WriteLine("\n" + (person as Professor).Print());
                            if (person is Student)
                                Console.WriteLine("\n" + (person as Student).Display());
                        }
                    }
                }
            }
        }

        private static void CreatePerson(int choice, out Person person)
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            switch (choice)
            {
                case 1:
                    Console.Write("Number of books published: ");
                    int booksPublished = int.Parse(Console.ReadLine());
                    person = new Professor(name, booksPublished);
                    break;

                case 2:
                    Console.Write("Marks Percentage: ");
                    double marksPercentage = double.Parse(Console.ReadLine());
                    person = new Student(name, marksPercentage);
                    break;

                default:
                    Console.WriteLine("\nEnter proper choice\n");
                    person = null;
                    break;
            }
        }

        private static int GetChoice()
        {
            Console.Write("\nEnter Choice[1/2]: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        private static void PrintChoices()
        {
            Console.WriteLine("1. Create Professor");
            Console.WriteLine("2. Create Student");
        }
    }
}
