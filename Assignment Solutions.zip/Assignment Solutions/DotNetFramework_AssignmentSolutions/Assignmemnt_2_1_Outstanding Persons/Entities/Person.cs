﻿namespace Assignmemnt_2_1_Outstanding_Persons.Entities
{
    public abstract class Person
    {
        string name;
        public Person()
        {

        }

        public Person(string name)
        {
            this.name = name;
        }

        public string Name { get => name; set => name = value; }

        public abstract bool IsOutstanding();
    }
}
