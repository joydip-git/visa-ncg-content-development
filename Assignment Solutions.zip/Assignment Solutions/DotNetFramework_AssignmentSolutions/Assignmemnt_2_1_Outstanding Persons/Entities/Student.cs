﻿namespace Assignmemnt_2_1_Outstanding_Persons.Entities
{
    public class Student : Person
    {
        double percentage;
        public Student(string name, double percentage) : base(name)
        {
            this.percentage = percentage;
        }

        public double Percentage { get => percentage; set => percentage = value; }

        public override bool IsOutstanding()
        {
            return this.percentage > 85;
        }
        public string Display()
        {
            return "Name: " + this.Name + ", Percentage: " + this.percentage;
        }
    }
}
